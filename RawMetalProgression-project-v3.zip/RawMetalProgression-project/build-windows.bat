@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle was not found. Install Gradle 9.x and ensure gradle is on PATH.
  pause
  exit /b 1
)
gradle build
if errorlevel 1 (
  echo Build failed. See the error output above.
  pause
  exit /b 1
)
echo Build finished. Check build\libs for the JAR.
pause
