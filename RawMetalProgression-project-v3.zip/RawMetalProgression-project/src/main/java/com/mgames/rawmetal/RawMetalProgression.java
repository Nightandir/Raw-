package com.mgames.rawmetal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.loot.LootTable;
import java.util.List;

public final class RawMetalProgression implements ModInitializer {
    public static final String MOD_ID = "rawmetal";

    public static final Item RAW_IRON_CHUNK = register("raw_iron_chunk");
    public static final Item RAW_IRON_NUGGET = register("raw_iron_nugget");
    public static final Item RAW_COPPER_CHUNK = register("raw_copper_chunk");
    public static final Item RAW_COPPER_NUGGET = register("raw_copper_nugget");
    public static final Item RAW_GOLD_CHUNK = register("raw_gold_chunk");
    public static final Item RAW_GOLD_NUGGET = register("raw_gold_nugget");

    private static Item register(String path) {
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        return Registry.register(BuiltInRegistries.ITEM, id, new Item(new Item.Properties().setId(key)));
    }

    @Override
    public void onInitialize() {
        LootTableEvents.MODIFY_DROPS.register((table, context, drops) -> {
            if (table.is(Blocks.IRON_ORE.getLootTable().orElseThrow())
                    || table.is(Blocks.DEEPSLATE_IRON_ORE.getLootTable().orElseThrow())) {
                replaceStacks(drops, Items.RAW_IRON, RAW_IRON_CHUNK);
            }
            if (table.is(Blocks.COPPER_ORE.getLootTable().orElseThrow())
                    || table.is(Blocks.DEEPSLATE_COPPER_ORE.getLootTable().orElseThrow())) {
                replaceStacks(drops, Items.RAW_COPPER, RAW_COPPER_CHUNK);
            }
            if (table.is(Blocks.GOLD_ORE.getLootTable().orElseThrow())
                    || table.is(Blocks.DEEPSLATE_GOLD_ORE.getLootTable().orElseThrow())) {
                replaceStacks(drops, Items.RAW_GOLD, RAW_GOLD_CHUNK);
            }
        });
    }

    private static void replaceStacks(List<ItemStack> drops, Item from, Item to) {
        for (int i = 0; i < drops.size(); i++) {
            ItemStack stack = drops.get(i);
            if (stack.is(from)) drops.set(i, new ItemStack(to, stack.getCount()));
        }
    }
}
